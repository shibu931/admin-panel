'use client'
import ArticleList from './ArticleList'
import React, { Suspense, useEffect, useState } from 'react'
import SelectInput from '../common/SelectInput'
import ArticleEditorLayout from './ArticleEditorLayout'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { deleteArticle } from '@/lib/actions/article.action'

const ArticleLayout = ({ articles }) => {
    const [selected, setSelected] = useState('all')
    const [articleList, setArticleList] = useState(articles)
    const options = [{ value: 'all', label: 'All' }, { value: 'blog', label: 'Blog' }, { value: 'article', label: 'Article' }]
    const router = useRouter()
    async function handleDeleteClick(articleSlug){
        try {
            const result = await deleteArticle(articleSlug)
            if(result.success){
                toast.success('Success',{description:'Successfuly deleted article'})
                setArticleList((prevArticles) => prevArticles.filter((article) => article.slug !== articleSlug))
            }else{
                toast.error('Error',{description:'Error deleteing article'})
            }
        } catch (error) {
            console.log(error)
            toast.error('Error',{description:'Error deleteing article'})
        }
    }
    function handleEditClick(articleSlug){
        router.push(`/articles?editArticle=true&slug=${articleSlug}`)
    }
    useEffect(() => {
        if (selected !== 'all') {
            const filterdArticles = articles.filter((article) => article.type === selected);
            console.log("Filtered Articles ",filterdArticles);
            
            setArticleList(filterdArticles)
        } else {
            setArticleList(articles)
        }
    }, [selected])
    return (
        <div className='grid grid-cols-1 lg:grid-cols-10 p-4 gap-4'>
            <div className="lg:col-span-3">
                <div className="border rounded py-4 ps-2 pe-1">
                    <div className="pe-1 pb-3 border-b border-neutral-700 flex items-center justify-between h-12">
                        <h5 className='text-neutral-300 uppercase font-medium'>All Articles</h5>
                        <SelectInput options={options} selected={selected} setSelected={setSelected} placeholder='Article Type' label='Types' width='w-[130px]' />
                    </div>
                    <ArticleList articleList={articleList} handleDeleteClick={handleDeleteClick} handleEditClick={handleEditClick}/>
                </div>
            </div>
            <div className="lg:col-span-7 border rounded py-4 px-2">
                <Suspense fallback={<p>Loading...</p>}>
                    <ArticleEditorLayout articleList={articleList} setArticleList={setArticleList}/>
                </Suspense>
            </div>
        </div>
    )
}

export default ArticleLayout